chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    serverUrl: 'http://localhost:8000',
    filenamePattern: '{title}.{ext}',
    useCookies: true
  });
});

async function fetchWithTimeout(url, options, timeout = 30000) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    clearTimeout(id);
    return response;
  } catch (err) {
    clearTimeout(id);
    throw err;
  }
}

const MAX_LOGS = 300;
async function writeLog(level, src, msg) {
  try {
    const { logs = [] } = await chrome.storage.local.get('logs');
    logs.push({ t: Date.now(), level, src, msg });
    if (logs.length > MAX_LOGS) logs.splice(0, logs.length - MAX_LOGS);
    await chrome.storage.local.set({ logs });
  } catch {}
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getVideoInfo') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]?.id) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'getVideoInfo' }, (resp) => {
          sendResponse(resp);
        });
      }
    });
    return true;
  }

  if (request.action === 'fetchFormats') {
    (async () => {
      try {
        const { serverUrl, useCookies } = await chrome.storage.local.get(['serverUrl', 'useCookies']);
        const params = new URLSearchParams({
          url: request.url,
          playlist: request.playlist || false,
          cookies: useCookies ? 'true' : 'false'
        });
        const resp = await fetchWithTimeout(`${serverUrl}/formats?${params}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' }
        }, 40000);
        const data = await resp.json();
        if (!resp.ok) { sendResponse({ success: false, error: data.detail || `Server error ${resp.status}` }); return; }
        sendResponse({ success: true, data });
      } catch (err) {
        await writeLog('error', 'bg', `fetchFormats: ${err.message}`);
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (request.action === 'getLogs') {
    (async () => {
      const { logs = [] } = await chrome.storage.local.get('logs');
      sendResponse(logs);
    })();
    return true;
  }

  if (request.action === 'fetchServerLogs') {
    (async () => {
      try {
        const { serverUrl } = await chrome.storage.local.get('serverUrl');
        const resp = await fetchWithTimeout(`${serverUrl}/logs?since=${request.since || 0}`, {}, 5000);
        if (resp.ok) { const data = await resp.json(); sendResponse(data); return; }
      } catch {}
      sendResponse([]);
    })();
    return true;
  }

  if (request.action === 'clearLogs') {
    chrome.storage.local.set({ logs: [] });
    sendResponse(true);
    return true;
  }

  if (request.action === 'fetchPlaylist') {
    (async () => {
      try {
        const { serverUrl, useCookies } = await chrome.storage.local.get(['serverUrl', 'useCookies']);
        const params = new URLSearchParams({
          url: request.url,
          cookies: useCookies ? 'true' : 'false'
        });
        const resp = await fetchWithTimeout(`${serverUrl}/playlist?${params}`, {}, 25000);
        const data = await resp.json();
        if (!resp.ok) { sendResponse({ success: false, error: data.detail || `Server error ${resp.status}` }); return; }
        sendResponse({ success: true, data });
      } catch (err) {
        await writeLog('error', 'bg', `fetchPlaylist: ${err.message}`);
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (request.action === 'startDownload') {
    (async () => {
      try {
        const { serverUrl, useCookies } = await chrome.storage.local.get(['serverUrl', 'useCookies']);
        const params = new URLSearchParams({
          url: request.url,
          format_id: request.formatId || '',
          type: request.type || 'video_combined',
          quality: request.quality || 'best',
          ext: request.ext || 'mp4',
          cookies: request.cookies || (useCookies ? 'true' : 'false'),
          filename: request.filename || 'video'
        });
        const resp = await fetchWithTimeout(`${serverUrl}/download?${params}`, {}, 30000);
        const data = await resp.json();
        if (!resp.ok) { sendResponse({ success: false, error: data.detail || `Server error ${resp.status}` }); return; }
        sendResponse({ success: true, ...data });
      } catch (err) {
        await writeLog('error', 'bg', `startDownload: ${err.message}`);
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (request.action === 'downloadStatus') {
    (async () => {
      try {
        const { serverUrl } = await chrome.storage.local.get('serverUrl');
        const resp = await fetchWithTimeout(`${serverUrl}/download/status/${request.downloadId}`, {}, 10000);
        const data = await resp.json();
        if (!resp.ok) { sendResponse({ success: false, error: data.detail || `Server error ${resp.status}` }); return; }
        sendResponse({ success: true, ...data });
      } catch (err) {
        await writeLog('error', 'bg', `downloadStatus: ${err.message}`);
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (request.action === 'checkServer') {
    (async () => {
      try {
        const resp = await fetchWithTimeout(`${request.serverUrl}/health`, {}, 5000);
        const data = await resp.json();
        if (!resp.ok) { sendResponse({ success: false, error: data.detail || `Server error ${resp.status}` }); return; }
        sendResponse({ success: true, data });
      } catch (err) {
        await writeLog('error', 'bg', `checkServer: ${err.message}`);
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (request.action === 'restartServer') {
    (async () => {
      try {
        const { serverUrl } = await chrome.storage.local.get('serverUrl');
        await fetchWithTimeout(`${serverUrl}/restart`, { method: 'POST' }, 3000);
        sendResponse({ success: true });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (request.action === 'shutdownServer') {
    (async () => {
      try {
        const { serverUrl } = await chrome.storage.local.get('serverUrl');
        await fetchWithTimeout(`${serverUrl}/shutdown`, { method: 'POST' }, 3000);
        sendResponse({ success: true });
      } catch (err) {
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (request.action === 'cancelDownload') {
    (async () => {
      try {
        const { serverUrl } = await chrome.storage.local.get('serverUrl');
        await fetchWithTimeout(`${serverUrl}/download/cancel/${request.downloadId}`, { method: 'POST' }, 5000);
        sendResponse({ success: true });
      } catch (err) {
        await writeLog('error', 'bg', `cancelDownload: ${err.message}`);
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true;
  }

  if (request.action === 'openWindow') {
    (async () => {
      try {
        const tab = await chrome.tabs.get(request.tabId);
        const win = await chrome.windows.get(tab.windowId);
        const left = win.left + win.width - 340;
        const top = win.top + 40;
        const popup = await chrome.windows.create({
          url: `popup.html?pinnedTabId=${request.tabId}`,
          type: 'popup',
          width: 320,
          height: 440,
          left: Math.max(left, 0),
          top: Math.max(top, 0)
        });
        pinnedPopups[request.tabId] = popup.id;
        sendResponse({ opened: true, windowId: popup.id });
      } catch (e) {
        await writeLog('error', 'bg', `openWindow: ${e.message}`);
        chrome.windows.create({
          url: 'popup.html',
          type: 'popup',
          width: 320,
          height: 420
        });
        sendResponse({ opened: true });
      }
    })();
    return true;
  }
});

const pinnedPopups = {};

chrome.windows.onRemoved.addListener((windowId) => {
  for (const [tabId, wid] of Object.entries(pinnedPopups)) {
    if (wid === windowId) { delete pinnedPopups[tabId]; break; }
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (pinnedPopups[tabId]) {
    chrome.windows.remove(pinnedPopups[tabId]).catch(() => {});
    delete pinnedPopups[tabId];
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (pinnedPopups[tabId] && changeInfo.url) {
    chrome.runtime.sendMessage({ action: 'videoUrlChanged', url: changeInfo.url });
    chrome.windows.update(pinnedPopups[tabId], { focused: true });
  }
});

// Also bring popup to front when content script detects SPA navigation
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.action === 'videoUrlChanged' && sender.tab?.id) {
    const winId = pinnedPopups[sender.tab.id];
    if (winId) chrome.windows.update(winId, { focused: true });
  }
});