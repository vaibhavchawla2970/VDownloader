const YT_VIDEO_PATTERN = /^https:\/\/www\.youtube\.com\/(watch\?v=|shorts\/)/;

function extractVideoId(url) {
  const queryMatch = url.match(/[?&]v=([^&]+)/);
  if (queryMatch) return queryMatch[1];
  const shortsMatch = url.match(/youtube\.com\/shorts\/([^/?&]+)/);
  return shortsMatch ? shortsMatch[1] : null;
}

function getVideoInfo() {
  const url = window.location.href;
  if (!YT_VIDEO_PATTERN.test(url)) return null;

  const videoId = extractVideoId(url);
  if (!videoId) return null;

  const titleEl = document.querySelector('h1 yt-formatted-string');
  const title = titleEl ? titleEl.textContent.trim() : document.title.replace(' - YouTube', '');

  const thumbnail = `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;

  const durationEl = document.querySelector('span.ytp-time-duration');
  let duration = durationEl ? durationEl.textContent.trim() : '';

  const authorEl = document.querySelector('#owner #channel-name a');
  const author = authorEl ? authorEl.textContent.trim() : '';

  return { videoId, title, thumbnail, duration, author, url };
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'getVideoInfo') {
    sendResponse(getVideoInfo());
  }
});

// Reliable URL change detection (polling window.location.href directly)
let lastVideoUrl = window.location.href;

setInterval(() => {
  const current = window.location.href;
  if (current !== lastVideoUrl && YT_VIDEO_PATTERN.test(current)) {
    lastVideoUrl = current;
    chrome.runtime.sendMessage({ action: 'videoUrlChanged', url: current });
  }
}, 400);

window.addEventListener('popstate', () => {
  const current = window.location.href;
  if (current !== lastVideoUrl && YT_VIDEO_PATTERN.test(current)) {
    lastVideoUrl = current;
    chrome.runtime.sendMessage({ action: 'videoUrlChanged', url: current });
  }
});
