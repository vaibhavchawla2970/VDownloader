const DEFAULT_SERVER = 'http://localhost:8000';
let s = { serverUrl: DEFAULT_SERVER, filenamePattern: '{title}.{ext}', useCookies: true };
let video = null;
let formats = null;
let playlist = null;
let currentDlId = null;
let serverDlId = null;
let downloading = false;
let formatCache = null;

const videoQualities = [
  { value: 'best', label: 'Best' },
  { value: '2160p', label: '4K' },
  { value: '1080p', label: '1080p' },
  { value: '720p', label: '720p' },
  { value: '480p', label: '480p' },
  { value: '360p', label: '360p' },
];
const audioQualities = [
  { value: 'best', label: 'Best' },
  { value: '320', label: '320 kbps' },
  { value: '256', label: '256 kbps' },
  { value: '192', label: '192 kbps' },
  { value: '128', label: '128 kbps' },
  { value: '64', label: '64 kbps' },
];

const pinnedTabId = new URLSearchParams(location.search).get('pinnedTabId');
let lastPolledUrl = '';
async function writeLog(level, src, msg) {
  try {
    const { logs = [] } = await chrome.storage.local.get('logs');
    logs.push({ t: Date.now(), level, src, msg });
    if (logs.length > 300) logs.splice(0, logs.length - 300);
    await chrome.storage.local.set({ logs });
  } catch {}
}

document.addEventListener('DOMContentLoaded', async () => {
  const stored = await chrome.storage.local.get(['serverUrl', 'filenamePattern', 'useCookies']);
  s.serverUrl = stored.serverUrl || DEFAULT_SERVER;
  s.filenamePattern = stored.filenamePattern || '{title}.{ext}';
  s.useCookies = stored.useCookies !== false;
  document.getElementById('server-url').value = s.serverUrl;
  document.getElementById('filename-pattern').value = s.filenamePattern;
  document.getElementById('cookies-toggle').checked = s.useCookies;

  if (pinnedTabId) {
    document.getElementById('pin-btn').style.display = 'none';
    document.querySelector('.header-title').textContent = 'VDownloader \u00B7 Pinned';
  }

  initNav();
  initEvents();
  await checkServer();
  buildPlaylistControls();
  detectVideo();

  // Auto-refresh when navigating between Shorts (only in pinned window)
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.action === 'videoUrlChanged' && !downloading && pinnedTabId) {
      detectVideo();
    }
  });

  // Poll pinned tab URL every 600ms to catch any navigation (Shorts swiping, etc.)
  if (pinnedTabId) {
    setInterval(async () => {
      if (downloading) return;
      try {
        const tab = await chrome.tabs.get(parseInt(pinnedTabId));
        if (tab.url && tab.url !== lastPolledUrl) {
          lastPolledUrl = tab.url;
          detectVideo();
        }
      } catch { writeLog('warn', 'popup', 'poll interval: tab.get failed'); }
    }, 600);
  }
});

function initNav() {
  document.querySelectorAll('.nav-btn').forEach(b => {
    b.addEventListener('click', () => {
      document.querySelectorAll('.nav-btn').forEach(x => x.classList.remove('active'));
      document.querySelectorAll('.panel').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      document.getElementById('panel-' + b.dataset.tab).classList.add('active');
    });
  });
}

function initEvents() {
  document.getElementById('save-settings').addEventListener('click', saveSettings);
  document.getElementById('view-logs').addEventListener('click', openLogViewer);
  document.getElementById('log-close').addEventListener('click', closeLogViewer);
  document.getElementById('log-clear').addEventListener('click', clearLogs);
  document.getElementById('log-export').addEventListener('click', exportLogs);
  document.getElementById('dl-video').addEventListener('click', () => startDl('video'));
  document.getElementById('dl-playlist').addEventListener('click', dlPlaylist);
  document.getElementById('cancel-btn').addEventListener('click', cancelDl);
  document.getElementById('pin-btn').addEventListener('click', pinWindow);
  document.getElementById('pl-select-all').addEventListener('click', () => togglePlaylistItems(true));
  document.getElementById('pl-select-none').addEventListener('click', () => togglePlaylistItems(false));
  document.getElementById('srv-restart').addEventListener('click', restartServer);
  document.getElementById('srv-stop').addEventListener('click', stopServer);
  document.getElementById('srv-start').addEventListener('click', () => { toast('Run start_server_v1.2.9.vbs to start the server'); });

  document.getElementById('video-mode').addEventListener('click', (e) => {
    const btn = e.target.closest('.seg-btn');
    if (!btn || !formats) return;
    document.querySelectorAll('#video-mode .seg-btn').forEach(x => x.classList.remove('active'));
    btn.classList.add('active');
    renderVideo(formats);
  });

  document.querySelectorAll('#pl-mode .seg-btn').forEach(b => {
    b.addEventListener('click', () => {
      document.querySelectorAll('#pl-mode .seg-btn').forEach(x => x.classList.remove('active'));
      b.classList.add('active');
      buildPlaylistControls();
    });
  });
}

async function pinWindow() {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tabId = tabs[0]?.id;
    if (!tabId) return;
    chrome.runtime.sendMessage({ action: 'openWindow', tabId }, () => {
      window.close();
    });
  } catch (e) {
    chrome.runtime.sendMessage({ action: 'openWindow' });
    window.close();
  }
}

async function saveSettings() {
  s.serverUrl = document.getElementById('server-url').value.trim() || DEFAULT_SERVER;
  s.filenamePattern = document.getElementById('filename-pattern').value.trim() || '{title}.{ext}';
  s.useCookies = document.getElementById('cookies-toggle').checked;
  await chrome.storage.local.set({ serverUrl: s.serverUrl, filenamePattern: s.filenamePattern, useCookies: s.useCookies });
  await checkServer();
  toast('Saved');
}

async function checkServer() {
  const dot = document.getElementById('status-dot');
  const st = document.getElementById('srv-status');
  const ver = document.getElementById('srv-version');
  const ff = document.getElementById('srv-ffmpeg');
  const restartBtn = document.getElementById('srv-restart');
  const stopBtn = document.getElementById('srv-stop');
  const startBtn = document.getElementById('srv-start');
  const offNote = document.getElementById('srv-offline-note');
  try {
    const r = await chrome.runtime.sendMessage({ action: 'checkServer', serverUrl: s.serverUrl });
    if (r?.success) {
      dot.className = 'dot online';
      st.textContent = 'Connected';
      ver.textContent = r.data?.yt_dlp_version || '-';
      ff.textContent = r.data?.ffmpeg ? 'Yes' : 'No';
      enableBtns(true);
      restartBtn.classList.remove('hidden');
      stopBtn.classList.remove('hidden');
      startBtn.classList.add('hidden');
      offNote.classList.add('hidden');
      return;
    }
  } catch { writeLog('warn', 'popup', 'checkServer: request failed'); }
  dot.className = 'dot offline';
  st.textContent = 'Offline'; ver.textContent = '-'; ff.textContent = '-';
  enableBtns(false);
  restartBtn.classList.add('hidden');
  stopBtn.classList.add('hidden');
  startBtn.classList.remove('hidden');
  offNote.classList.remove('hidden');
}

function enableBtns(on) {
  document.getElementById('dl-video').disabled = !on;
  document.getElementById('dl-playlist').disabled = !on;
}

async function detectVideo() {
  let tabs;
  if (pinnedTabId) {
    const tab = await chrome.tabs.get(parseInt(pinnedTabId)).catch(() => null);
    tabs = tab ? [tab] : await chrome.tabs.query({ active: true, currentWindow: true });
  } else {
    tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  }
  const url = tabs[0]?.url || '';
  const tabTitle = tabs[0]?.title || '';
  const extractedTitle = tabTitle.replace(/\s*[-–|]\s*(YouTube|.*)$/i, '').trim() || 'Video';

  const card = document.getElementById('video-card');
  const empty = document.getElementById('empty-state');
  const loading = document.getElementById('loading-state');

  if (url.includes('youtube.com/playlist')) {
    document.querySelector('[data-tab="playlist"]').click();
    fetchPlaylist(url);
    return;
  }

  if (!url.includes('youtube.com/watch') && !url.includes('youtube.com/shorts/')) {
    card.classList.add('hidden');
    loading.classList.add('hidden');
    empty.classList.remove('hidden');
    return;
  }

  empty.classList.add('hidden');
  loading.classList.remove('hidden');
  card.classList.add('hidden');

  // Build fallback info from tab URL (instant, no server needed)
  const videoId = (url.match(/[?&]v=([^&]+)/) || url.match(/youtube\.com\/shorts\/([^/?&]+)/) || [])[1];
  const fallbackInfo = videoId ? {
    videoId, url,
    title: extractedTitle,
    thumbnail: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
    duration: '', author: ''
  } : null;

  // Try to get video info from content script (with retries)
  let info = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const r = await chrome.runtime.sendMessage({ action: 'getVideoInfo' });
      if (r) { info = r; break; }
    } catch { if (attempt === 2) writeLog('warn', 'popup', 'getVideoInfo: all retries failed'); }
    if (attempt < 2) await new Promise(r => setTimeout(r, 400));
  }

  // Use content script info if available, otherwise fallback to URL-based
  if (info || fallbackInfo) {
    video = info || fallbackInfo;
    showCard(video);
    loading.classList.add('hidden');
    card.classList.remove('hidden');
    fetchFormats(video.url);
  } else {
    loading.classList.add('hidden');
    empty.classList.remove('hidden');
  }

  // Auto-fetch playlist if URL has list parameter
  const listId = (url.match(/[?&]list=([^&]+)/) || [])[1];
  if (listId) {
    fetchPlaylist(url);
  }
}

function showCard(info) {
  document.getElementById('thumb').src = info.thumbnail || '';
  document.getElementById('video-title').textContent = info.title || '';
  document.getElementById('video-author').textContent = info.author || '';
  document.getElementById('duration-badge').textContent = info.duration || '';
}

async function fetchFormats(url) {
  // Check client-side cache first (instant)
  const cached = getFormatsFromCache(url);
  if (cached) {
    formats = cached;
    const cv = cached.videos?.[0];
    if (cv?.title && video) { video.title = cv.title; document.getElementById('video-title').textContent = cv.title; }
    renderVideo(cached);
    return;
  }

  document.getElementById('video-formats-loading').classList.remove('hidden');
  try {
    const r = await chrome.runtime.sendMessage({ action: 'fetchFormats', url, playlist: false, useCookies: s.useCookies });
    if (r?.success) {
      formats = r.data;
      const sv = r.data.videos?.[0];
      if (sv?.title && video) { video.title = sv.title; document.getElementById('video-title').textContent = sv.title; }
      formatCache = { url, data: r.data, expiry: Date.now() + 300000 };
      renderVideo(r.data);
    }
  } catch (err) {
    writeLog('error', 'popup', `fetchFormats: ${err?.message || 'unknown'}`);
    document.getElementById('video-options').innerHTML = '<div class="chip-empty">Check if server.py is running</div>';
    enableBtns(false);
  }
  document.getElementById('video-formats-loading').classList.add('hidden');
}

function getFormatsFromCache(url) {
  if (formatCache && formatCache.url === url && Date.now() < formatCache.expiry) {
    return formatCache.data;
  }
  return null;
}

function renderVideo(data) {
  const g = document.getElementById('video-options');
  g.innerHTML = '';
  const v = data.videos?.[0];
  if (!v) { g.innerHTML = '<div class="chip-empty">No formats</div>'; return; }

  const mode = document.querySelector('#video-mode .seg-btn.active')?.dataset?.mode || 'video_combined';
  let sourceFormats = [];
  if (mode === 'video_combined') {
    sourceFormats = [...(v.combined || []), ...(v.video_only || [])];
  } else if (mode === 'video_only') {
    sourceFormats = v.video_only || [];
  } else {
    sourceFormats = v.audio_only || [];
  }

  if (!sourceFormats.length) { g.innerHTML = '<div class="chip-empty">No formats</div>'; return; }

  if (mode === 'audio_only') {
    const sorted = sourceFormats.sort((a, b) => (b.abr || 0) - (a.abr || 0));
    for (const f of sorted) {
      const d = document.createElement('div');
      d.className = 'chip';
      d.dataset.quality = f.abr || 'best';
      d.dataset.formatId = f.format_id;
      d.dataset.type = 'audio_only';
      d.dataset.ext = f.ext;
      d.innerHTML = `<span class="chip-label">${f.label || f.abr + ' kbps'}</span><span class="chip-size">${f.size_label || ''}</span><span class="chip-ext">${f.ext}</span>`;
      d.onclick = () => { g.querySelectorAll('.chip').forEach(x => x.classList.remove('selected')); d.classList.add('selected'); };
      g.appendChild(d);
    }
  } else {
    const map = new Map();
    for (const f of sourceFormats) {
      const k = f.height || 0;
      if (!map.has(k) || (f.type === 'combined' && map.get(k).type !== 'combined')) map.set(k, f);
    }
    const sorted = [...map.values()].sort((a, b) => (b.height || 0) - (a.height || 0));
    for (const f of sorted) {
      const d = document.createElement('div');
      d.className = 'chip';
      d.dataset.quality = f.height || 'best';
      d.dataset.formatId = f.format_id;
      d.dataset.type = f.type === 'combined' ? 'video_combined' : 'video_only';
      d.dataset.ext = f.ext;
      d.dataset.hasAudio = f.has_audio ? 'true' : 'false';
      const sizeInfo = f.size_label ? ` · ${f.size_label}` : '';
      const mergeNote = f.type === 'video_only' && mode === 'video_combined' ? ' +audio' : '';
      d.innerHTML = `<span class="chip-label">${f.label || (f.height || '?') + 'p'}</span><span class="chip-size">${sizeInfo}</span><span class="chip-ext">${f.ext}${mergeNote}</span>`;
      d.onclick = () => { g.querySelectorAll('.chip').forEach(x => x.classList.remove('selected')); d.classList.add('selected'); };
      g.appendChild(d);
    }
  }
  g.firstChild?.classList.add('selected');
  enableBtns(true);
}

async function startDl(type) {
  if (!video || downloading) return;
  const sel = document.querySelector('#panel-video .chip.selected');
  if (!sel) return;

  const formatId = sel.dataset.formatId;
  const dlMode = document.querySelector('#video-mode .seg-btn.active')?.dataset?.mode || 'video_combined';
  const ext = sel.dataset.ext;

  if (!formatId) return;

  const filename = buildFilename(video.title, ext, sel.dataset.quality, video.videoId);

  showProgress('Queuing download...', 0);
  downloading = true;
  currentDlId = Date.now() + '_' + Math.random().toString(36).slice(2);
  const btn = document.getElementById('dl-video');
  btn.disabled = true;

  try {
    // Start download on server
    const startResp = await chrome.runtime.sendMessage({
      action: 'startDownload',
      url: video.url,
      formatId: formatId,
      type: dlMode,
      quality: sel.dataset.quality,
      ext: ext,
      cookies: s.useCookies ? 'true' : 'false',
      filename: filename
    });

    if (!startResp?.success || !startResp.download_id) {
      throw new Error(startResp?.error || 'Failed to start download');
    }

    serverDlId = startResp.download_id;
    const downloadId = startResp.download_id;
    const fileUrl = startResp.file_url;

    // Poll for completion
    await pollAndDownload(downloadId, fileUrl, filename, currentDlId);

    downloading = false;
    btn.disabled = false;
    currentDlId = null;
    serverDlId = null;
  } catch (err) {
    writeLog('error', 'popup', `startDl: ${err.message}`);
    downloading = false;
    btn.disabled = false;
    currentDlId = null;
    serverDlId = null;
    setProgressText('Error: ' + err.message);
    hideProgressAfter(3000);
  }
}

async function pollAndDownload(downloadId, fileUrl, filename, uiDlId) {
  return new Promise(async (resolve, reject) => {
    const maxAttempts = 600; // 10 minutes max (1 sec intervals)
    let attempts = 0;

    const poll = async () => {
      try {
        attempts++;
        const statusResp = await chrome.runtime.sendMessage({
          action: 'downloadStatus',
          downloadId: downloadId
        });

        if (!statusResp?.success) {
          if (attempts >= maxAttempts) {
            reject(new Error('Download timeout'));
            return;
          }
          setProgressText(`Processing... ${attempts}s`);
          setTimeout(poll, 1000);
          return;
        }

        const { status, progress, error } = statusResp;

        if (status === 'error') {
          reject(new Error(error || 'Download failed'));
          return;
        }

        if (status === 'downloading') {
          fillProgress(progress);
          setProgressText(`Downloading... ${progress.toFixed(0)}%`);
        } else if (status === 'queued') {
          setProgressText('Queued...');
        }

        if (status === 'completed') {
          fillProgress(100);
          setProgressText('Saved to Downloads');
          hideProgressAfter(3000);
          resolve();
          return;
        }

        if (attempts >= maxAttempts) {
          reject(new Error('Download timeout'));
          return;
        }

        setTimeout(poll, 1000);
      } catch (err) {
        writeLog('error', 'popup', `pollAndDownload: ${err.message}`);
        reject(err);
      }
    };

    await poll();
  });
}

function cancelDl() {
  if ((currentDlId || serverDlId) && downloading) {
    chrome.runtime.sendMessage({
      action: 'cancelDownload',
      downloadId: serverDlId
    });
    currentDlId = null;
    serverDlId = null;
    downloading = false;
    enableBtns(true);
  }
}

function togglePlaylistItems(checked) {
  document.querySelectorAll('#pl-entries .pl-entry input[type="checkbox"]').forEach(cb => cb.checked = checked);
}

function buildPlaylistControls() {
  const mode = document.querySelector('#pl-mode .seg-btn.active')?.dataset?.mode || 'video_combined';
  const container = document.getElementById('pl-controls');
  container.innerHTML = '';
  if (mode === 'audio') {
    const qualRow = document.createElement('div');
    qualRow.className = 'row';
    qualRow.innerHTML = `<label class="row-label">Bitrate</label><select class="row-select" id="pl-quality">${audioQualities.map(q => `<option value="${q.value}">${q.label}</option>`).join('')}</select>`;
    container.appendChild(qualRow);
  } else {
    const qualRow = document.createElement('div');
    qualRow.className = 'row';
    qualRow.innerHTML = `<label class="row-label">Quality</label><select class="row-select" id="pl-quality">${videoQualities.map(q => `<option value="${q.value}">${q.label}</option>`).join('')}</select>`;
    container.appendChild(qualRow);
  }
}

async function fetchPlaylist(url) {
  const empty = document.getElementById('pl-empty');
  const loading = document.getElementById('pl-loading');
  const ready = document.getElementById('playlist-ready');
  empty.classList.add('hidden');
  loading.classList.remove('hidden');
  ready.classList.add('hidden');
  try {
    const r = await chrome.runtime.sendMessage({ action: 'fetchPlaylist', url, useCookies: s.useCookies });
    loading.classList.add('hidden');
    if (r?.success && r.data?.entries?.length) {
      playlist = r.data;
      showPlaylist(r.data);
    } else {
      empty.classList.remove('hidden');
    }
  } catch (err) {
    writeLog('error', 'popup', `fetchPlaylist: ${err?.message || 'unknown'}`);
    loading.classList.add('hidden');
    empty.classList.remove('hidden');
  }
}

function showPlaylist(data) {
  document.getElementById('pl-empty').classList.add('hidden');
  document.getElementById('playlist-ready').classList.remove('hidden');
  document.getElementById('pl-title').textContent = data.title || 'Playlist';
  document.getElementById('pl-count').textContent = data.count + ' videos';
  const c = document.getElementById('pl-entries');
  c.innerHTML = '';
  for (const e of (data.entries || []).slice(0, 50)) {
    const d = document.createElement('div');
    d.className = 'pl-entry';
    d.innerHTML = `
      <input type="checkbox" checked>
      <span class="pl-idx">${e.index || '?'}</span>
      <img class="pl-thumb" src="${e.thumbnail || ''}" alt="" onerror="this.style.display='none'">
      <span class="pl-title">${esc((e.title || '').slice(0, 50))}</span>
    `;
    c.appendChild(d);
  }
  document.getElementById('dl-playlist').disabled = false;
}

async function dlPlaylist() {
  if (!playlist?.entries?.length || downloading) return;
  const mode = document.querySelector('#pl-mode .seg-btn.active')?.dataset?.mode || 'video_combined';
  const quality = document.getElementById('pl-quality').value;
  const entries = document.querySelectorAll('#pl-entries .pl-entry');
  const checked = [];
  entries.forEach((entry, i) => {
    const cb = entry.querySelector('input[type="checkbox"]');
    if (cb?.checked && playlist.entries[i]) checked.push(playlist.entries[i]);
  });
  if (!checked.length) { toast('Select at least one video'); return; }

  downloading = true;
  document.getElementById('dl-playlist').disabled = true;
  let started = 0, failed = 0;
  showProgress(`Fetching formats for ${checked.length} videos...`, 10);

  const formatPromises = checked.map((e, idx) =>
    chrome.runtime.sendMessage({ action: 'fetchFormats', url: e.url, playlist: false, useCookies: s.useCookies })
      .then(fmtData => ({ entry: e, idx, fmtData })).catch(err => ({ entry: e, idx, fmtData: null, error: err }))
  );
  const formatResults = await Promise.all(formatPromises);

  for (let i = 0; i < formatResults.length; i++) {
    const { entry: e, fmtData, error } = formatResults[i];
    showProgress(`Playlist: ${i + 1}/${checked.length} - ${e.title.slice(0, 30)}...`, Math.round((i / checked.length) * 100));
    if (error || !fmtData?.success || !fmtData?.data?.videos?.[0]) { failed++; continue; }
    const v = fmtData.data.videos[0];
    let targetFormats = [];
    if (mode === 'audio') targetFormats = v.audio_only || [];
    else if (mode === 'video_only') targetFormats = v.video_only || [];
    else targetFormats = [...(v.combined || []), ...(v.video_only || [])];
    let selectedFormat = null;
    if (quality === 'best') {
      selectedFormat = targetFormats.reduce((a, b) => ((a.height || 0) >= (b.height || 0) ? a : b));
    } else { const th = parseInt(quality); selectedFormat = targetFormats.find(f => f.height === th) || targetFormats[0]; }
    if (!selectedFormat?.format_id) { failed++; continue; }
    const filename = buildFilename(e.title, selectedFormat.ext, selectedFormat.height || 'best', e.id);
    const startResp = await chrome.runtime.sendMessage({
      action: 'startDownload', url: e.url, formatId: selectedFormat.format_id,
      type: mode === 'audio' ? 'audio_only' : (mode === 'video_only' ? 'video_only' : 'video_combined'),
      quality: selectedFormat.height || 'best', ext: selectedFormat.ext,
      cookies: s.useCookies ? 'true' : 'false', filename: filename
    });
    if (startResp?.success && startResp?.download_id) { await pollAndDownload(startResp.download_id, startResp.file_url, filename, startResp.download_id); started++; }
    else { failed++; }
  }
  downloading = false;
  document.getElementById('dl-playlist').disabled = false;
  if (started > 0) toast(`Playlist complete: ${started} succeeded${failed > 0 ? `, ${failed} failed` : ''}`);
  else toast('All downloads failed');
  hideProgressAfter(3000);
}

function showProgress(text, pct) {
  document.getElementById('progress').classList.remove('hidden');
  fillProgress(pct);
  setProgressText(text);
}

function fillProgress(pct) {
  document.getElementById('progress-fill').style.width = pct + '%';
}

function setProgressText(text) {
  document.getElementById('progress-text').textContent = text;
}

function hideProgressAfter(ms) {
  setTimeout(() => document.getElementById('progress').classList.add('hidden'), ms);
}

function buildFilename(title, ext, quality, id) {
  return s.filenamePattern
    .replace('{title}', sanitizeFilename(title || 'video'))
    .replace('{ext}', ext)
    .replace('{quality}', quality)
    .replace('{id}', id || '');
}

function sanitizeFilename(name) {
  return name.replace(/[\\/:*?"<>|]/g, '_').trim().slice(0, 100);
}

function humanSize(bytes) {
  if (!bytes) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  let i = 0;
  while (bytes >= 1024 && i < units.length - 1) {
    bytes /= 1024;
    i++;
  }
  return bytes.toFixed(1) + ' ' + units[i];
}

async function restartServer() {
  const r = await chrome.runtime.sendMessage({ action: 'restartServer' });
  if (r?.success) {
    toast('Server restarting...');
    setTimeout(checkServer, 2000);
  } else {
    toast('Restart failed: ' + (r?.error || 'unknown'));
  }
}
async function stopServer() {
  const r = await chrome.runtime.sendMessage({ action: 'shutdownServer' });
  if (r?.success) {
    toast('Server stopped');
    setTimeout(checkServer, 1000);
  } else {
    toast('Stop failed: ' + (r?.error || 'unknown'));
  }
}

let _logPollInterval = null;
let _lastServerLogId = 0;

function _fmtTime(ts) {
  const d = typeof ts === 'number' && ts > 1e10 ? new Date(ts) : new Date(ts);
  return d.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
}

function _appendLogEntry(list, entry, source) {
  const d = document.createElement('div');
  d.className = 'log-entry';
  const level = entry.level || 'info';
  const msg = esc(entry.msg || '');
  const time = _fmtTime(entry.t);
  const src = esc(entry.src || source || '-');
  const srcClass = entry.src === 'server' ? 'green' : (level === 'error' || level === 'warn' ? level : 'info');
  d.innerHTML = `<span class="log-time">${time}</span><span class="log-level ${level}">${level}</span><span class="log-src ${srcClass}">${src}</span><span class="log-msg">${msg}</span>`;
  list.appendChild(d);
  return d;
}

async function openLogViewer() {
  const list = document.getElementById('log-list');
  list.innerHTML = '';
  _lastServerLogId = 0;

  // Fetch extension logs
  const extLogs = await chrome.runtime.sendMessage({ action: 'getLogs' });
  if (Array.isArray(extLogs)) {
    for (const l of extLogs) _appendLogEntry(list, l, 'ext');
  }

  // Fetch server logs
  try {
    const svrLogs = await chrome.runtime.sendMessage({ action: 'fetchServerLogs', since: 0 });
    if (Array.isArray(svrLogs) && svrLogs.length) {
      _lastServerLogId = svrLogs[svrLogs.length - 1].id || 0;
      for (const l of svrLogs) _appendLogEntry(list, { ...l, src: 'server' }, 'server');
    }
  } catch {}

  if (!list.children.length) {
    list.innerHTML = '<div class="log-empty">No logs recorded yet</div>';
  }

  list.scrollTop = list.scrollHeight;
  document.getElementById('view-logs').classList.add('hidden');
  document.getElementById('log-viewer').classList.remove('hidden');

  // Start live polling for server logs
  if (_logPollInterval) clearInterval(_logPollInterval);
  _logPollInterval = setInterval(async () => {
    const list2 = document.getElementById('log-list');
    if (!list2) return;
    try {
      const logs = await chrome.runtime.sendMessage({ action: 'fetchServerLogs', since: _lastServerLogId });
      if (Array.isArray(logs) && logs.length) {
        _lastServerLogId = logs[logs.length - 1].id || _lastServerLogId;
        // Remove empty-state placeholder if present
        const empty = list2.querySelector('.log-empty');
        if (empty) empty.remove();
        for (const l of logs) _appendLogEntry(list2, { ...l, src: 'server' }, 'server');
        list2.scrollTop = list2.scrollHeight;
      }
    } catch {}
  }, 2000);
}

function closeLogViewer() {
  if (_logPollInterval) { clearInterval(_logPollInterval); _logPollInterval = null; }
  document.getElementById('log-viewer').classList.add('hidden');
  document.getElementById('view-logs').classList.remove('hidden');
}

async function clearLogs() {
  await chrome.runtime.sendMessage({ action: 'clearLogs' });
  document.getElementById('log-badge').textContent = '';
  document.getElementById('log-badge').classList.add('hidden');
  document.getElementById('log-list').innerHTML = '<div class="log-empty">Logs cleared</div>';
}

async function exportLogs() {
  const r = await chrome.runtime.sendMessage({ action: 'getLogs' });
  const logs = Array.isArray(r) ? r : [];
  if (!logs.length) { toast('No logs to export'); return; }
  const lines = logs.map(l => {
    const t = new Date(l.t).toISOString();
    return `[${t}] [${l.level}] [${l.src}] ${l.msg}`;
  });
  const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  chrome.downloads.download({ url, filename: `vdownloader_logs_${Date.now()}.txt`, saveAs: true });
}

function toast(msg) {
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  document.body.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => { el.classList.remove('show'); setTimeout(() => el.remove(), 250); }, 1800);
}

function esc(s) {
  const d = document.createElement('div');
  d.textContent = s;
  return d.innerHTML;
}

