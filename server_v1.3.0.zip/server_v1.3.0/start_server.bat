@echo off
title VDownloader Server

echo ============================================
echo   VDownloader Server - Starting...
echo ============================================
echo.

:: Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed!
    echo.
    echo Please install Python first:
    echo   1. Go to https://www.python.org/downloads/
    echo   2. Download Python 3.8 or newer
    echo   3. Run the installer - MAKE SURE you check:
    echo      "Add Python to PATH" at the bottom of the installer
    echo   4. Restart this script after installing
    echo.
    pause
    exit /b 1
)

echo [OK] Python found
python --version

echo.
echo [..] Installing/updating dependencies...
python -m pip install --upgrade pip yt-dlp fastapi uvicorn 2>&1 | findstr /V "already satisfied Requirement"

if %errorlevel% neq 0 (
    echo [WARN] Some dependencies may not have installed correctly.
    echo        The server might still work if they are already installed.
)

echo.
echo ============================================
echo   Starting VDownloader Server
echo   Server URL: http://localhost:8000
echo   Press Ctrl+C to stop
echo ============================================
echo.

python server.py

pause
