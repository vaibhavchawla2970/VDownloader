import json, os, re, shutil, subprocess, sys, tempfile, time, uuid, urllib.parse, logging, threading
from collections import deque
from pathlib import Path
from fastapi import FastAPI, HTTPException, Query, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

app = FastAPI(title="VDownloader API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

# --- Log capture (for extension log viewer) ---
_log_buffer = deque(maxlen=500)
_log_lock = threading.Lock()
_log_counter = 0

class CaptureHandler(logging.Handler):
    def emit(self, record):
        global _log_counter
        with _log_lock:
            _log_counter += 1
            _log_buffer.append({
                "id": _log_counter,
                "t": time.time(),
                "level": record.levelname.lower(),
                "msg": self.format(record)
            })

_capture_handler = CaptureHandler()
_capture_handler.setFormatter(logging.Formatter('%(message)s'))
logging.getLogger().addHandler(_capture_handler)
# Also capture uvicorn access logs
logging.getLogger("uvicorn").addHandler(_capture_handler)
logging.getLogger("uvicorn.access").addHandler(_capture_handler)

def _add_log(level, msg):
    global _log_counter
    with _log_lock:
        _log_counter += 1
        _log_buffer.append({"id": _log_counter, "t": time.time(), "level": level, "msg": msg})

@app.get("/logs")
def get_logs(since: int = Query(0, description="Return only log entries with id > this value")):
    with _log_lock:
        if since <= 0:
            return list(_log_buffer)
        return [e for e in _log_buffer if e["id"] > since]

# --- Find yt-dlp & ffmpeg ---
def _find_ytdlp():
    for c in [os.environ.get("YTDL_PATH"), "yt-dlp", "yt-dlp.exe"]:
        if c:
            try:
                subprocess.run([c, "--version"], capture_output=True, timeout=10)
                return c
            except: pass
    return [sys.executable, "-m", "yt_dlp"]

def _find_ffmpeg():
    for c in [shutil.which("ffmpeg"), shutil.which("ffmpeg.exe"),
              r"C:\ProgramData\chocolatey\bin\ffmpeg.exe", r"C:\Program Files\ffmpeg\bin\ffmpeg.exe",
              r"C:\ffmpeg\bin\ffmpeg.exe", os.path.expanduser(r"~\scoop\apps\ffmpeg\current\bin\ffmpeg.exe")]:
        if c and os.path.exists(c): return c
    return None

YTDL_PATH = _find_ytdlp()
FFMPEG = _find_ffmpeg()
TEMP = os.path.join(tempfile.gettempdir(), "vdownloader")
os.makedirs(TEMP, exist_ok=True)
_downloads = {}
_format_cache = {}

def _ytdl_cmd(args, use_cookies=True):
    cmd = [*YTDL_PATH] if isinstance(YTDL_PATH, list) else [YTDL_PATH]
    if use_cookies:
        env = os.environ.get("YTDL_COOKIES")
        if env: cmd += ["--cookies", env]
        else: cmd += ["--cookies-from-browser", "chrome"]
    return cmd + ["--no-warnings"] + args

def _run_ytdl(args, timeout=60, use_cookies=True):
    cmd = _ytdl_cmd(args, use_cookies)
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "yt-dlp timed out")
    except FileNotFoundError:
        raise HTTPException(500, "yt-dlp not found. Install: pip install yt-dlp")

def _human_size(b):
    if not b: return "~?"
    for u in ("B","KB","MB","GB"):
        if b < 1024: return f"{b:.1f} {u}"
        b /= 1024
    return f"{b:.1f} GB"

def _clean_url(url, keep_playlist=False):
    if keep_playlist:
        return url
    parsed = urllib.parse.urlparse(url)
    query = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
    for param in ['list', 'start_radio', 'index']:
        query.pop(param, None)
    if not query:
        new_query = ""
    else:
        new_query = urllib.parse.urlencode(query, doseq=True)
    return urllib.parse.urlunparse(parsed._replace(query=new_query))

# --- Health ---
@app.get("/health")
def health():
    try:
        v = _run_ytdl(["--version"])[0].strip()
    except: v = "not found"
    return {"status":"ok","yt_dlp_version":v,"ffmpeg":FFMPEG is not None}

# --- Formats ---
@app.post("/formats")
def get_formats(url: str = Query(...), playlist: str = Query("false"), cookies: str = Query("true")):
    use_cookies = cookies.lower() == "true"
    is_playlist = playlist.lower() == "true"
    clean_url = _clean_url(url, keep_playlist=is_playlist)

    key = f"{clean_url}|{is_playlist}|{use_cookies}"
    if key in _format_cache and time.time() < _format_cache[key]["expiry"]:
        return _format_cache[key]["data"]

    args = ["--dump-json", "--no-download"]
    if not is_playlist: args.append("--no-playlist")
    args.append(clean_url)

    first_err = None
    if use_cookies:
        stdout, stderr = _run_ytdl(args, 30, True)
        if not stdout:
            first_err = stderr[:500]
            stdout, stderr = _run_ytdl(args, 30, False)
    else:
        stdout, stderr = _run_ytdl(args, 30, False)

    if not stdout:
        msg = first_err if first_err else stderr[:500]
        raise HTTPException(400, f"Could not fetch video info:\n{msg}")

    def proc(f):
        ext = f.get("ext","")
        vc = f.get("vcodec","none")
        ac = f.get("acodec","none")
        h = f.get("height",0) or 0
        abr = f.get("abr",0) or 0
        fps = f.get("fps",0) or 0
        sz = f.get("filesize") or f.get("filesize_approx") or 0
        fid = f.get("format_id","")
        note = f.get("format_note","") or ""
        tbr = f.get("tbr",0) or 0
        return {"ext":ext,"height":h,"abr":int(abr),"fps":fps,"filesize":sz,"format_id":fid,"note":note,"tbr":tbr,"has_v":vc!="none","has_a":ac!="none"}

    results = []
    for line in stdout.strip().splitlines():
        if not line.strip(): continue
        try: info = json.loads(line)
        except: continue
        fmts = [proc(f) for f in info.get("formats",[])]

        combined, video_only, audio_only = [], [], []
        seen_c, seen_v, seen_a = set(), set(), set()

        for f in fmts:
            label = f"{f['height']}p" if f['height'] else "?"
            if f['has_v'] and f['has_a']:
                k = f['height']
                if k not in seen_c:
                    seen_c.add(k)
                    ds = f['filesize']
                    if ds == 0 and f['tbr'] > 0 and info.get("duration",0) > 0:
                        ds = int(f['tbr']*1000/8*info["duration"])
                    combined.append({"format_id":f['format_id'],"ext":f['ext'],"height":f['height'],"fps":f['fps'],
                        "filesize":f['filesize'],"size_label":_human_size(ds),
                        "label":f"{label} {f['note']}" if f['note'] else label,"type":"combined","has_audio":True})
            elif f['has_v'] and not f['has_a']:
                k = f['height']
                if k not in seen_v:
                    seen_v.add(k)
                    lbl = label
                    if f['fps'] and f['fps'] > 30: lbl += f" {f['fps']}fps"
                    video_only.append({"format_id":f['format_id'],"ext":f['ext'],"height":f['height'],"fps":f['fps'],
                        "filesize":f['filesize'],"size_label":_human_size(f['filesize']),"label":lbl,"type":"video_only","has_audio":False})
            elif f['has_a'] and not f['has_v']:
                k = f['abr']
                if k not in seen_a:
                    seen_a.add(k)
                    audio_only.append({"format_id":f['format_id'],"ext":f['ext'],"abr":f['abr'],
                        "filesize":f['filesize'],"size_label":_human_size(f['filesize']),
                        "label":f"{f['abr']} kbps ({f['ext']})" if f['abr'] else f"Audio ({f['ext']})","type":"audio_only","has_audio":True})

        combined.sort(key=lambda x: x['height'], reverse=True)
        video_only.sort(key=lambda x: x['height'], reverse=True)
        audio_only.sort(key=lambda x: x['abr'], reverse=True)
        results.append({"id":info.get("id",""),"title":info.get("title","Unknown"),"duration":info.get("duration",0),
            "uploader":info.get("uploader",""),"thumbnail":info.get("thumbnail",""),
            "webpage_url":info.get("webpage_url",url),"combined":combined,"video_only":video_only,"audio_only":audio_only})

    resp = {"videos": results, "has_ffmpeg": FFMPEG is not None}
    _format_cache[key] = {"data": resp, "expiry": time.time() + 300}
    return resp

# --- Download ---
def _download_worker(did, url, fmt_id, dtype, quality, ext, use_cookies, filename):
    try:
        _downloads[did]["status"] = "downloading"
        out = os.path.join(TEMP, f"{did}.%(ext)s")

        args = ["--newline", "--progress", "-o", out]
        if FFMPEG: args += ["--ffmpeg-location", os.path.dirname(FFMPEG)]

        if dtype == "audio":
            ext_map = {"mp3":"mp3","m4a":"m4a","opus":"opus","flac":"flac","wav":"wav"}
            audio_ext = ext_map.get(ext, "mp3")
            f = fmt_id if fmt_id else f"bestaudio[abr<={quality}]/bestaudio" if quality != "best" else "bestaudio/best"
            args += ["-f", f, "--extract-audio", "--audio-format", audio_ext, "--audio-quality", "0" if quality=="best" else quality]
        elif dtype == "video_only":
            f = fmt_id if fmt_id else (f"bestvideo[height<={quality}]" if quality!="best" else "bestvideo")
            args += ["-f", f]
        else: # video_combined
            f = f"{fmt_id}+bestaudio/best" if fmt_id and FFMPEG else (fmt_id if fmt_id else "bestvideo+bestaudio/best")
            args += ["-f", f, "--merge-output-format", "mp4"]

        args.append(url)

        cookie_options = [use_cookies, False] if use_cookies else [False]
        proc = None
        for use_c in cookie_options:
            if proc is not None:
                _add_log("warn", f"download_worker({did}): retrying without cookies")
                _downloads[did]["status"] = "downloading"
                _downloads[did]["progress"] = 0

            cmd = _ytdl_cmd(args, use_c)
            _add_log("info", f"download_worker({did}): starting yt-dlp")

            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, bufsize=1)

            for line in iter(proc.stdout.readline, ''):
                if not line: break
                line = line.strip()
                m = re.search(r'(\d+\.?\d*)%', line)
                if m and "[download]" in line: _downloads[did]["progress"] = float(m.group(1))

            proc.wait()

            if proc.returncode == 0:
                proc = None
                break

        if proc and proc.returncode != 0:
            err = (proc.stderr.read() or "Unknown error").strip()
            _add_log("error", f"download_worker({did}): FAILED - {err[:300]}")
            _downloads[did]["status"] = "error"
            _downloads[did]["error"] = err
            return

        # Find output file
        fp = None
        for f in os.listdir(TEMP):
            if f.startswith(did):
                fp = os.path.join(TEMP, f)
                break

        if not fp or not os.path.exists(fp):
            _downloads[did]["status"] = "error"
            _downloads[did]["error"] = "Output file not found"
            return

        sz = os.path.getsize(fp)
        if sz == 0:
            os.remove(fp)
            _downloads[did]["status"] = "error"
            _downloads[did]["error"] = "File is empty"
            return

        # Save to user's Downloads folder instead of triggering browser download
        try:
            downloads_dir = os.path.join(os.path.expanduser("~"), "Downloads")
            final_path = os.path.join(downloads_dir, filename)
            base, ext = os.path.splitext(final_path)
            counter = 1
            while os.path.exists(final_path):
                final_path = f"{base}_{counter}{ext}"
                counter += 1
            shutil.move(fp, final_path)
            fp = final_path
        except Exception as e:
            _add_log("warn", f"download_worker({did}): could not move to Downloads - {e}")

        _downloads[did].update({"status":"completed","progress":100,"filepath":fp,"filename":os.path.basename(fp),"completed_at":time.time()})
        _add_log("info", f"download_worker({did}): saved to {fp} - {_human_size(sz)}")

    except Exception as e:
        _add_log("error", f"download_worker({did}): exception - {e}")
        _downloads[did]["status"] = "error"
        _downloads[did]["error"] = str(e)


@app.api_route("/download", methods=["GET","POST"])
def start_download(background_tasks: BackgroundTasks, url: str = Query(...),
    format_id: str = Query(""), type: str = Query("video_combined"),
    quality: str = Query("best"), ext: str = Query("mp4"),
    cookies: str = Query("true"), filename: str = Query("video")):
    use_cookies = cookies.lower() == "true"
    url = _clean_url(url, keep_playlist=False)
    did = str(uuid.uuid4())[:12]
    safe = re.sub(r'[\\/:*?"<>|]', '_', filename).strip()[:100]
    if not safe.endswith(f".{ext}"): safe = f"{safe}.{ext}"
    dtype = "audio" if type == "audio_only" else type
    _downloads[did] = {"status":"queued","progress":0,"filepath":None,"filename":safe,"created_at":time.time(),
        "url":url,"format_id":format_id,"type":dtype,"quality":quality,"ext":ext}
    background_tasks.add_task(_download_worker, did, url, format_id, dtype, quality, ext, use_cookies, safe)
    return {"success":True,"download_id":did,"file_url":f"http://localhost:8000/file/{did}","filename":safe}

@app.get("/download/status/{download_id}")
def download_status(download_id: str):
    if download_id not in _downloads: raise HTTPException(404, "Download not found")
    i = _downloads[download_id]
    return {"download_id":download_id,"status":i["status"],"progress":i["progress"],"filename":i["filename"],
        "file_url":f"http://localhost:8000/file/{download_id}" if i["status"]=="completed" else None,"error":i.get("error")}

@app.get("/file/{download_id}")
def serve_file(download_id: str):
    if download_id not in _downloads: raise HTTPException(404, "Download not found")
    i = _downloads[download_id]
    if i["status"] != "completed": raise HTTPException(400, f"Not ready: {i['status']}")
    if not i.get("filepath") or not os.path.exists(i["filepath"]): raise HTTPException(404, "File not found")
    return FileResponse(i["filepath"], filename=i["filename"], media_type="application/octet-stream")

@app.post("/download/cancel/{download_id}")
def cancel_download(download_id: str):
    if download_id not in _downloads: raise HTTPException(404, "Download not found")
    i = _downloads[download_id]
    if i["status"] in ("downloading","queued"):
        i["status"] = "cancelled"
        if i.get("filepath") and os.path.exists(i["filepath"]):
            try: os.remove(i["filepath"])
            except: pass
    return {"success":True,"status":i["status"]}

@app.get("/playlist")
def get_playlist(url: str = Query(...), cookies: str = Query("true")):
    use_cookies = cookies.lower() == "true"
    p_stdout, p_stderr = _run_ytdl(["--flat-playlist","--dump-json", url], 20, use_cookies)
    if not p_stdout and use_cookies:
        p_stdout, p_stderr = _run_ytdl(["--flat-playlist","--dump-json", url], 20, False)
    if not p_stdout: raise HTTPException(400, f"Could not fetch playlist:\n{p_stderr[:500]}")
    entries = []
    for line in p_stdout.strip().splitlines():
        if not line.strip(): continue
        try:
            e = json.loads(line)
            entries.append({"id":e.get("id",""),"title":e.get("title","Unknown"),
                "url":e.get("webpage_url") or f"https://www.youtube.com/watch?v={e.get('id','')}",
                "duration":e.get("duration",0),"thumbnail":e.get("thumbnail",""),"index":e.get("playlist_index",0)})
        except: continue
    title = "Playlist"
    try:
        i_stdout = _run_ytdl(["--dump-json","--no-playlist", url], 30, use_cookies)[0]
        if not i_stdout and use_cookies:
            i_stdout = _run_ytdl(["--dump-json","--no-playlist", url], 30, False)[0]
        if i_stdout:
            title = json.loads(i_stdout.splitlines()[0]).get("playlist_title","Playlist")
    except: pass
    return {"title":title,"count":len(entries),"entries":entries}

# --- Server management ---
@app.post("/restart")
def restart_server(background_tasks: BackgroundTasks):
    _add_log("info", "Server restart requested via API")
    background_tasks.add_task(_do_restart)
    return {"success": True}

def _do_restart():
    time.sleep(0.5)
    _add_log("info", "Spawning new server process...")
    try:
        pythonw = sys.executable.replace("python.exe", "pythonw.exe")
        if not os.path.exists(pythonw):
            pythonw = sys.executable
        script = os.path.abspath(__file__)
        subprocess.Popen([pythonw, script], creationflags=subprocess.CREATE_NO_WINDOW)
    except Exception as e:
        _add_log("error", f"Restart spawn failed: {e}")
    os._exit(0)

@app.post("/shutdown")
def shutdown_server(background_tasks: BackgroundTasks):
    _add_log("info", "Server shutdown requested via API")
    background_tasks.add_task(_do_shutdown)
    return {"success": True}

def _do_shutdown():
    time.sleep(0.3)
    os._exit(0)

if __name__ == "__main__":
    import uvicorn
    p = int(os.environ.get("PORT", 8000))
    _add_log("info", f"Server starting on http://0.0.0.0:{p}")
    _add_log("info", f"yt-dlp: {YTDL_PATH}")
    _add_log("info", f"ffmpeg: {'FOUND' if FFMPEG else 'NOT FOUND (4K needs ffmpeg)'}")
    uvicorn.run(app, host="0.0.0.0", port=p, log_level="info")
